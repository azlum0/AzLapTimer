// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime2 = globalThis.Deno;
  if (!runtime2) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime2.stdin.readable,
    writable: runtime2.stdout.writable,
    exit: (code) => runtime2.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin12 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin12 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin12);
}
function fromBase64(data) {
  const latin12 = atob(data);
  const bytes = new Uint8Array(latin12.length);
  for (let i = 0; i < latin12.length; i++)
    bytes[i] = latin12.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime2) {
    this.id = id;
    this.runtime = runtime2;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// src/shared/protocol.ts
var REF_MODES = ["best", "session", "last"];
function isCommand(value) {
  if (typeof value !== "object" || value === null) return false;
  const t = value.t;
  if (t === "hello" || t === "clearBest" || t === "resetSession") return true;
  return t === "ref" && REF_MODES.includes(value.mode);
}

// src/shared/engine.ts
var BINS = 1e3;
var MIN_LAP_SECONDS = 5;
var CROSSING_JITTER_SECONDS = 2;
var MAX_GAP_SECONDS = 2;
var OFFICIAL_WINDOW_SECONDS = 5;
var OFFICIAL_TOLERANCE_SECONDS = 0.5;
var MAX_LAPS_KEPT = 200;
function newTrace(started) {
  return {
    times: new Float32Array(BINS + 1).fill(NaN),
    speeds: new Float32Array(BINS + 1).fill(NaN),
    started,
    clean: started,
    maxBin: -1,
    vmax: 0
  };
}
function at(values, lapDist) {
  const x = Math.min(Math.max(lapDist, 0), 1) * BINS;
  const i = Math.floor(x);
  if (i >= BINS) return values[BINS];
  return values[i] + (x - i) * (values[i + 1] - values[i]);
}
function patch(values) {
  let last = -1;
  for (let i = 0; i <= BINS; i++) {
    if (Number.isNaN(values[i])) continue;
    if (last >= 0 && i - last > 1) {
      for (let j = last + 1; j < i; j++) {
        values[j] = values[last] + (j - last) / (i - last) * (values[i] - values[last]);
      }
    }
    last = i;
  }
}
var round3 = (value) => Math.round(value * 1e3) / 1e3;
var round3OrNull = (value) => value === null ? null : round3(value);
var LapEngine = class {
  constructor(host) {
    this.host = host;
  }
  host;
  refMode = "best";
  key = "";
  connected = false;
  sim = "";
  track = "";
  car = "";
  laps = [];
  lapCount = 0;
  sessionBest = null;
  allTimeBest = null;
  lastReference = null;
  lastDelta = null;
  cur = null;
  lapStart = 0;
  lastCrossAt = -Infinity;
  prev = null;
  latest = null;
  /** where the car was when it last stopped being live */
  parked = null;
  pending = null;
  /** lap times of the sim's own references, worked out at the line for those it does not publish */
  learned = {};
  simSessionBest = null;
  update(s) {
    const key = `${s.sim}|${s.trackId}|${s.carId}`;
    if (key !== this.key) this.switchCombo(key, s);
    if (!this.connected) {
      this.connected = true;
      this.host.changed?.();
    }
    this.latest = s;
    const simSessionBest = s.simDelta?.session?.refTime ?? null;
    if (simSessionBest !== this.simSessionBest) {
      this.simSessionBest = simSessionBest;
      this.host.changed?.();
    }
    if (!s.live) {
      if (this.prev) this.parked = this.prev;
      this.prev = null;
      return;
    }
    const p = this.prev ?? this.resume(s);
    if (!p || !this.cur) {
      this.beginPartial(s);
      return;
    }
    const dt = s.sessionTime - p.sessionTime;
    if (dt < 0 || dt > MAX_GAP_SECONDS) {
      this.beginPartial(s);
      return;
    }
    if (dt === 0) return;
    const moved = s.lapDist - p.lapDist;
    if (moved < -0.5) {
      if (s.sessionTime - this.lastCrossAt < MIN_LAP_SECONDS) return;
      this.cross(p, s, dt);
    } else if (moved > 0.5) {
      if (s.sessionTime - this.lastCrossAt < CROSSING_JITTER_SECONDS) return;
      this.beginPartial(s);
      return;
    } else if (moved > 0) {
      const length = s.trackLength > 0 ? s.trackLength : 3e3;
      const reach = Math.max(0.02, 3 * Math.max(s.speed, p.speed) * dt / length);
      if (moved > reach) {
        this.beginPartial(s);
        return;
      }
      this.fill(p.lapDist, p.sessionTime - this.lapStart, p.speed, s.lapDist, s.sessionTime - this.lapStart, s.speed);
    }
    const cur = this.cur;
    if (s.inPit || !s.lapValid) cur.clean = false;
    if (s.speed > cur.vmax) cur.vmax = s.speed;
    this.prev = s;
    this.reconcile(s);
  }
  /** the sim went away. the laps stay, in case it is the same session coming back. */
  idle() {
    if (!this.connected) return;
    this.connected = false;
    this.latest = null;
    this.prev = null;
    this.parked = null;
    this.cur = null;
    this.pending = null;
    this.host.changed?.();
  }
  setRefMode(mode) {
    if (mode === this.refMode) return;
    this.refMode = mode;
    this.host.changed?.();
  }
  clearBest() {
    this.allTimeBest = null;
    this.sessionBest = null;
    this.lastReference = null;
    if (this.key) this.host.saveBest(this.key, null);
    this.host.changed?.();
  }
  resetSession() {
    this.laps = [];
    this.lapCount = 0;
    this.sessionBest = null;
    this.lastReference = null;
    this.lastDelta = null;
    this.pending = null;
    this.host.changed?.();
  }
  frame() {
    const s = this.latest;
    const cur = this.cur;
    const reference = this.reference();
    const frame = {
      t: "f",
      sim: this.connected ? this.sim : null,
      live: false,
      pit: false,
      lap: this.lapCount + 1,
      time: null,
      delta: null,
      deltaV: null,
      pred: null,
      speed: 0,
      vmax: 0,
      valid: true,
      ref: reference ? round3(reference.lapTime) : null
    };
    if (!s) return frame;
    const sim = s.simDelta?.[this.refMode];
    const simRef = sim ? this.simRefTime(s) : null;
    if (sim) frame.ref = simRef === null ? null : round3(simRef);
    frame.live = s.live;
    frame.pit = s.inPit;
    frame.speed = round3(s.speed);
    if (!s.live || !cur) return frame;
    const time = s.sessionTime - this.lapStart;
    frame.vmax = round3(cur.vmax);
    frame.valid = cur.clean || !cur.started;
    if (cur.started || s.lapTime >= 0) frame.time = round3(time);
    if (sim) {
      if (sim.delta !== null) {
        frame.delta = round3(sim.delta);
        frame.deltaV = sim.rate < 0.9 ? round3(-s.speed * sim.rate / (1 - sim.rate)) : null;
        frame.pred = simRef === null ? null : round3(simRef + sim.delta);
      }
    } else if (cur.started && reference) {
      const delta = time - at(reference.times, s.lapDist);
      frame.delta = round3(delta);
      frame.deltaV = round3(s.speed - at(reference.speeds, s.lapDist));
      frame.pred = round3(reference.lapTime + delta);
    }
    return frame;
  }
  session() {
    return {
      t: "s",
      sim: this.connected ? this.sim : null,
      track: this.track,
      car: this.car,
      refMode: this.refMode,
      laps: this.laps.slice(-50).map((lap) => ({ ...lap, time: round3(lap.time), vmax: round3(lap.vmax) })),
      sessionBest: round3OrNull(this.simSessionBest ?? this.sessionBest?.lapTime ?? null),
      allTimeBest: this.allTimeBest ? round3(this.allTimeBest.lapTime) : null,
      lastDelta: this.lastDelta === null ? null : round3(this.lastDelta)
    };
  }
  /** lap time of the reference the sim is measuring against in the current mode */
  simRefTime(s) {
    return s.simDelta?.[this.refMode]?.refTime ?? this.learned[this.refMode] ?? this.reference()?.lapTime ?? null;
  }
  reference() {
    if (this.refMode === "last") return this.lastReference;
    if (this.refMode === "session") return this.sessionBest;
    return this.allTimeBest ?? this.sessionBest;
  }
  switchCombo(key, s) {
    this.key = key;
    this.sim = s.sim;
    this.track = s.track;
    this.car = s.car;
    this.laps = [];
    this.lapCount = 0;
    this.sessionBest = null;
    this.lastReference = null;
    this.lastDelta = null;
    this.cur = null;
    this.prev = null;
    this.parked = null;
    this.pending = null;
    this.learned = {};
    this.lastCrossAt = -Infinity;
    this.allTimeBest = this.host.loadBest(key);
    this.host.changed?.();
  }
  /** a pause leaves the car where it was, so the lap carries on; anything else starts over */
  resume(s) {
    const parked = this.parked;
    this.parked = null;
    if (!parked || !this.cur) return null;
    const gap = s.sessionTime - parked.sessionTime;
    if (gap < 0 || gap > MAX_GAP_SECONDS) return null;
    return Math.abs(s.lapDist - parked.lapDist) < 0.01 ? parked : null;
  }
  /** joined mid-lap, so this lap can show a time but never set one */
  beginPartial(s) {
    this.cur = newTrace(false);
    this.cur.maxBin = Math.floor(s.lapDist * BINS);
    this.cur.vmax = s.speed;
    this.lapStart = s.sessionTime - Math.max(s.lapTime, 0);
    this.prev = s;
  }
  fill(d0, t0, v0, d1, t1, v1) {
    const cur = this.cur;
    const b0 = d0 * BINS;
    const b1 = d1 * BINS;
    if (b1 <= b0) return;
    const first = Math.max(Math.ceil(b0), cur.maxBin + 1);
    const last = Math.min(Math.floor(b1), BINS);
    for (let b = first; b <= last; b++) {
      const f = (b - b0) / (b1 - b0);
      cur.times[b] = t0 + f * (t1 - t0);
      cur.speeds[b] = v0 + f * (v1 - v0);
    }
    if (last > cur.maxBin) cur.maxBin = last;
  }
  cross(p, s, dt) {
    const before = 1 - p.lapDist;
    const span = before + s.lapDist;
    const f = span > 0 ? before / span : 0;
    const crossAt = p.sessionTime + f * dt;
    const crossSpeed = p.speed + f * (s.speed - p.speed);
    const done = this.cur;
    if (done.started) {
      this.fill(p.lapDist, p.sessionTime - this.lapStart, p.speed, 1, crossAt - this.lapStart, crossSpeed);
      this.complete(done, crossAt - this.lapStart, p, crossAt);
    }
    this.lapStart = crossAt;
    this.lastCrossAt = crossAt;
    this.cur = newTrace(true);
    this.cur.times[0] = 0;
    this.cur.speeds[0] = crossSpeed;
    this.cur.maxBin = 0;
    this.cur.vmax = Math.max(crossSpeed, s.speed);
    this.fill(0, 0, crossSpeed, s.lapDist, s.sessionTime - crossAt, s.speed);
  }
  complete(done, time, before, crossAt) {
    const valid = done.clean && time >= MIN_LAP_SECONDS;
    const record = { n: ++this.lapCount, time, valid, vmax: done.vmax };
    this.laps.push(record);
    if (this.laps.length > MAX_LAPS_KEPT) this.laps.shift();
    const sim = before.simDelta?.[this.refMode];
    const against = this.reference();
    this.lastDelta = sim ? sim.delta : against ? time - against.lapTime : null;
    for (const mode of REF_MODES) {
      const own = before.simDelta?.[mode];
      if (!own || own.refTime !== null || own.delta === null) continue;
      this.learned[mode] = valid && own.delta < 0 ? time : time - own.delta;
    }
    let reference = null;
    if (valid) {
      patch(done.times);
      patch(done.speeds);
      reference = { lapTime: time, times: done.times, speeds: done.speeds, date: Date.now() };
      this.lastReference = reference;
      if (!this.sessionBest || time < this.sessionBest.lapTime) this.sessionBest = reference;
      if (!this.allTimeBest || time < this.allTimeBest.lapTime) {
        this.allTimeBest = reference;
        this.host.saveBest(this.key, reference);
      }
    }
    this.pending = {
      record,
      reference,
      ownDelta: !sim,
      simLastBefore: before.lastLapTime,
      deadline: crossAt + OFFICIAL_WINDOW_SECONDS
    };
    this.host.changed?.();
  }
  /** the sim's own time for the lap arrives a moment after the line and replaces ours */
  reconcile(s) {
    const pending = this.pending;
    if (!pending) return;
    if (s.sessionTime > pending.deadline) {
      this.pending = null;
      return;
    }
    const official = s.lastLapTime;
    if (official <= 0 || Math.abs(official - pending.simLastBefore) < 1e-4) return;
    this.pending = null;
    if (Math.abs(official - pending.record.time) > OFFICIAL_TOLERANCE_SECONDS) return;
    if (pending.ownDelta && this.lastDelta !== null) this.lastDelta += official - pending.record.time;
    pending.record.time = official;
    const reference = pending.reference;
    if (reference) {
      reference.lapTime = official;
      reference.times[BINS] = official;
      if (reference === this.allTimeBest) this.host.saveBest(this.key, reference);
    }
    this.host.changed?.();
  }
};

// src/shared/codec.ts
function toBase642(values) {
  const bytes = new Uint8Array(values.buffer, values.byteOffset, values.byteLength);
  let binary2 = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    binary2 += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(binary2);
}
function fromBase642(text2) {
  let binary2;
  try {
    binary2 = atob(text2);
  } catch {
    return null;
  }
  if (binary2.length !== (BINS + 1) * 4) return null;
  const bytes = new Uint8Array(binary2.length);
  for (let i = 0; i < binary2.length; i++) bytes[i] = binary2.charCodeAt(i);
  return new Float32Array(bytes.buffer);
}
function encodeReference(reference) {
  return {
    lapTime: reference.lapTime,
    date: reference.date,
    times: toBase642(reference.times),
    speeds: toBase642(reference.speeds)
  };
}
function decodeReference(stored) {
  if (typeof stored !== "object" || stored === null) return null;
  const { lapTime, date, times, speeds } = stored;
  if (typeof lapTime !== "number" || !(lapTime > 0) || typeof times !== "string" || typeof speeds !== "string") {
    return null;
  }
  const t = fromBase642(times);
  const v = fromBase642(speeds);
  if (!t || !v) return null;
  return { lapTime, date: typeof date === "number" ? date : 0, times: t, speeds: v };
}

// extension/win32.ts
var FILE_MAP_READ = 4;
var MEMORY_BASIC_INFORMATION_SIZE = 48;
var REGION_SIZE_OFFSET = 24;
var SYMBOLS = {
  OpenFileMappingA: { parameters: ["u32", "i32", "buffer"], result: "pointer" },
  MapViewOfFile: { parameters: ["pointer", "u32", "u32", "u32", "usize"], result: "pointer" },
  VirtualQuery: { parameters: ["pointer", "buffer", "usize"], result: "usize" },
  UnmapViewOfFile: { parameters: ["pointer"], result: "i32" },
  CloseHandle: { parameters: ["pointer"], result: "i32" }
};
var kernel32 = null;
function openMapping(name) {
  if (Deno.build.os !== "windows") return null;
  kernel32 ??= Deno.dlopen("kernel32.dll", SYMBOLS);
  const k = kernel32.symbols;
  const handle = k.OpenFileMappingA(FILE_MAP_READ, 0, new TextEncoder().encode(`${name}\0`));
  if (handle === null) return null;
  const base = k.MapViewOfFile(handle, FILE_MAP_READ, 0, 0, 0n);
  if (base === null) {
    k.CloseHandle(handle);
    return null;
  }
  const info = new Uint8Array(MEMORY_BASIC_INFORMATION_SIZE);
  const wrote = k.VirtualQuery(base, info, BigInt(info.length));
  const size = wrote ? Number(new DataView(info.buffer).getBigUint64(REGION_SIZE_OFFSET, true)) : 0;
  if (size <= 0) {
    k.UnmapViewOfFile(base);
    k.CloseHandle(handle);
    return null;
  }
  const view = new DataView(Deno.UnsafePointerView.getArrayBuffer(base, size));
  let open = true;
  return {
    view,
    close() {
      if (!open) return;
      open = false;
      k.UnmapViewOfFile(base);
      k.CloseHandle(handle);
    }
  };
}
var CONSOLE_SYMBOLS = {
  GetConsoleProcessList: { parameters: ["buffer", "u32"], result: "u32" },
  FreeConsole: { parameters: [], result: "i32" }
};
function releaseOwnConsole() {
  if (Deno.build.os !== "windows") return false;
  const lib = Deno.dlopen("kernel32.dll", CONSOLE_SYMBOLS);
  try {
    const attached = new Uint32Array(4);
    const count = lib.symbols.GetConsoleProcessList(new Uint8Array(attached.buffer), attached.length);
    return count === 1 && lib.symbols.FreeConsole() !== 0;
  } finally {
    lib.close();
  }
}

// extension/layout.ts
var SIZES = {
  u8: 1,
  i8: 1,
  bool: 1,
  u16: 2,
  i16: 2,
  u32: 4,
  i32: 4,
  f32: 4,
  u64: 8,
  i64: 8,
  f64: 8,
  ptr: 8
};
function struct(fields, pack = 8) {
  const at4 = {};
  let offset = 0;
  let align = 1;
  for (const [name, type, count = 1] of fields) {
    const size = typeof type === "string" ? SIZES[type] : type.size;
    const natural = typeof type === "string" ? SIZES[type] : type.align;
    const fieldAlign = Math.min(natural, pack);
    offset = Math.ceil(offset / fieldAlign) * fieldAlign;
    if (!name.startsWith("_")) at4[name] = offset;
    offset += size * count;
    if (fieldAlign > align) align = fieldAlign;
  }
  return { size: Math.ceil(offset / align) * align, align, at: at4 };
}
var utf8 = new TextDecoder();
var latin1 = new TextDecoder("windows-1252");
function cstr(view, offset, max, encoding = "utf8") {
  const bytes = new Uint8Array(view.buffer, view.byteOffset + offset, max);
  const end = bytes.indexOf(0);
  const text2 = (encoding === "utf8" ? utf8 : latin1).decode(bytes.slice(0, end < 0 ? max : end));
  return text2.trim();
}

// extension/sources/ams2.ts
var AMS2_MAPPING = "$pcars2$";
var STRING = 64;
var PARTICIPANTS = 64;
var participant = struct([
  ["_isActive", "bool"],
  ["_name", "u8", STRING],
  ["_worldPosition", "f32", 3],
  ["currentLapDistance", "f32"],
  ["_racePosition_lapsCompleted_currentLap", "u32", 3],
  ["_currentSector", "i32"]
]);
var ams2Layout = struct([
  ["version", "u32"],
  ["_buildVersionNumber", "u32"],
  ["gameState", "u32"],
  ["_sessionState_raceState", "u32", 2],
  ["viewedParticipantIndex", "i32"],
  ["numParticipants", "i32"],
  ["participants", participant, PARTICIPANTS],
  ["_unfilteredThrottle_to_unfilteredClutch", "f32", 4],
  ["carName", "u8", STRING],
  ["_carClassName", "u8", STRING],
  ["_lapsInEvent", "u32"],
  ["trackLocation", "u8", STRING],
  ["trackVariation", "u8", STRING],
  ["trackLength", "f32"],
  ["_numSectors", "i32"],
  ["lapInvalidated", "bool"],
  ["_bestLapTime", "f32"],
  ["lastLapTime", "f32"],
  ["currentTime", "f32"],
  ["_splitTimeAhead_to_worldFastestSector3Time", "f32", 18],
  ["_highestFlagColour_highestFlagReason", "u32", 2],
  ["pitMode", "u32"],
  ["_pitSchedule_carFlags", "u32", 2],
  ["_oilTempCelsius_to_fuelCapacity", "f32", 7],
  ["speed", "f32"],
  ["_rpm_to_steering", "f32", 6],
  ["_gear_numGears", "i32", 2],
  ["_odometerKM", "f32"],
  ["_antiLockActive", "bool"],
  ["_lastOpponentCollisionIndex", "i32"],
  ["_lastOpponentCollisionMagnitude", "f32"],
  ["_boostActive", "bool"],
  ["_boostAmount", "f32"],
  ["_orientation_to_extentsCentre", "f32", 21],
  ["_tyreFlags_to_tyreInternalAirTemp", "u32", 72],
  ["_crashState", "u32"],
  ["_aeroDamage_engineDamage", "f32", 2],
  ["_ambientTemperature_to_cloudBrightness", "f32", 7],
  ["sequenceNumber", "u32"]
]);
var at2 = ams2Layout.at;
var GAME_INGAME_PLAYING = 2;
var PIT_MODE_NONE = 0;
var OLDEST_VERSION = 5;
var NEWEST_PLAUSIBLE_VERSION = 100;
var Ams2Reader = class _Ams2Reader {
  constructor(view, now = () => performance.now() / 1e3) {
    this.view = view;
    this.now = now;
  }
  view;
  now;
  clock = 0;
  lastPollAt = null;
  static create(view, log) {
    const version = view.byteLength >= ams2Layout.size ? view.getUint32(at2.version, true) : -1;
    if (version < OLDEST_VERSION || version > NEWEST_PLAUSIBLE_VERSION) {
      log(`Automobilista 2 shared memory reports version ${version}, which this reader does not know; skipping it`);
      return null;
    }
    return new _Ams2Reader(view);
  }
  pulse() {
    return this.view.getUint32(at2.sequenceNumber, true);
  }
  poll() {
    const v = this.view;
    for (let attempt = 0; attempt < 3; attempt++) {
      const sequence = v.getUint32(at2.sequenceNumber, true);
      if (sequence % 2 === 1) continue;
      const sample = this.read();
      if (v.getUint32(at2.sequenceNumber, true) === sequence) return sample;
    }
    return null;
  }
  read() {
    const v = this.view;
    const viewed = v.getInt32(at2.viewedParticipantIndex, true);
    const trackLength = v.getFloat32(at2.trackLength, true);
    if (viewed < 0 || viewed >= PARTICIPANTS || viewed >= v.getInt32(at2.numParticipants, true) || !(trackLength > 0)) {
      this.lastPollAt = null;
      return null;
    }
    const live = v.getUint32(at2.gameState, true) === GAME_INGAME_PLAYING;
    const now = this.now();
    if (live && this.lastPollAt !== null) this.clock += Math.min(now - this.lastPollAt, 0.25);
    this.lastPollAt = live ? now : null;
    const location = cstr(v, at2.trackLocation, STRING);
    const variation = cstr(v, at2.trackVariation, STRING);
    const car = cstr(v, at2.carName, STRING);
    const metres = v.getFloat32(
      at2.participants + viewed * participant.size + participant.at.currentLapDistance,
      true
    );
    return {
      sim: "Automobilista 2",
      track: variation ? `${location} ${variation}` : location,
      trackId: `${location}/${variation}`,
      car,
      carId: car,
      trackLength,
      sessionTime: this.clock,
      live,
      inPit: v.getUint32(at2.pitMode, true) !== PIT_MODE_NONE,
      lapDist: Math.min(Math.max(metres / trackLength, 0), 1),
      lapTime: v.getFloat32(at2.currentTime, true),
      lastLapTime: v.getFloat32(at2.lastLapTime, true),
      speed: v.getFloat32(at2.speed, true),
      lapValid: v.getUint8(at2.lapInvalidated) === 0
    };
  }
};

// extension/sources/iracing.ts
var IRACING_MAPPING = "Local\\IRSDKMemMapFileName";
var STATUS = 4;
var SESSION_INFO_UPDATE = 12;
var SESSION_INFO_LEN = 16;
var SESSION_INFO_OFFSET = 20;
var NUM_VARS = 24;
var VAR_HEADER_OFFSET = 28;
var NUM_BUF = 32;
var VAR_BUF = 48;
var VAR_BUF_SIZE = 16;
var MAX_BUFS = 4;
var STATUS_CONNECTED = 1;
var VAR_HEADER_SIZE = 144;
var VAR_TYPE = 0;
var VAR_OFFSET = 4;
var VAR_NAME = 16;
var VAR_NAME_LENGTH = 32;
var TYPE_BOOL = 1;
var TYPE_INT = 2;
var TYPE_BITFIELD = 3;
var TYPE_FLOAT = 4;
var TYPE_DOUBLE = 5;
var TRACK_SURFACE_NOT_IN_WORLD = -1;
var WANTED = [
  "SessionTime",
  "IsOnTrack",
  "IsReplayPlaying",
  "OnPitRoad",
  "PlayerTrackSurface",
  "LapDistPct",
  "LapCurrentLapTime",
  "LapLastLapTime",
  "LapBestLapTime",
  "Speed",
  "PlayerCarMyIncidentCount",
  "LapDeltaToBestLap",
  "LapDeltaToBestLap_DD",
  "LapDeltaToBestLap_OK",
  "LapDeltaToSessionBestLap",
  "LapDeltaToSessionBestLap_DD",
  "LapDeltaToSessionBestLap_OK",
  // the sim itself spells this one with the stray l
  "LapDeltaToSessionLastlLap",
  "LapDeltaToSessionLastlLap_DD",
  "LapDeltaToSessionLastlLap_OK"
];
function yamlValue(text2, key) {
  const match = new RegExp(`^\\s*${key}:[ \\t]*(.*)$`, "m").exec(text2);
  return match ? match[1].trim().replace(/^["']|["']$/g, "") : "";
}
function parseSessionInfo(text2) {
  const name = yamlValue(text2, "TrackDisplayName") || yamlValue(text2, "TrackName");
  const config = yamlValue(text2, "TrackConfigName");
  const trackId = [yamlValue(text2, "TrackName"), config].filter(Boolean).join("/");
  const km = /([\d.]+)\s*km/.exec(yamlValue(text2, "TrackLength"));
  let car = "";
  let carId = "";
  const mine = yamlValue(text2, "DriverCarIdx");
  const drivers = text2.slice(Math.max(text2.search(/^DriverInfo:/m), 0));
  for (const driver of drivers.split(/^\s*-\s*CarIdx:[ \t]*/m).slice(1)) {
    if (/^(\d+)/.exec(driver)?.[1] !== mine) continue;
    car = yamlValue(driver, "CarScreenName");
    carId = yamlValue(driver, "CarPath") || car;
    break;
  }
  return {
    track: config && config !== "null" ? `${name} ${config}` : name,
    trackId: trackId || name,
    trackLength: km ? Number(km[1]) * 1e3 : 0,
    car: car || carId,
    carId
  };
}
var IRacingReader = class {
  constructor(view) {
    this.view = view;
  }
  view;
  vars = /* @__PURE__ */ new Map();
  infoUpdate = -1;
  info = { track: "", trackId: "", trackLength: 0, car: "", carId: "" };
  tick = 0;
  incidents = null;
  incidentsRead = 0;
  pulse() {
    return this.latest()?.tick ?? this.tick;
  }
  poll() {
    const v = this.view;
    if ((v.getInt32(STATUS, true) & STATUS_CONNECTED) === 0) {
      this.vars.clear();
      this.infoUpdate = -1;
      return null;
    }
    if (this.vars.size === 0) this.readVarHeaders();
    const infoUpdate = v.getInt32(SESSION_INFO_UPDATE, true);
    if (infoUpdate !== this.infoUpdate) {
      this.infoUpdate = infoUpdate;
      this.info = parseSessionInfo(
        cstr(v, v.getInt32(SESSION_INFO_OFFSET, true), v.getInt32(SESSION_INFO_LEN, true), "latin1")
      );
    }
    for (let attempt = 0; attempt < 3; attempt++) {
      const buf = this.latest();
      if (!buf) return null;
      const sample = this.read(buf.offset);
      if (v.getInt32(buf.slot, true) === buf.tick) {
        this.tick = buf.tick;
        this.incidents = this.incidentsRead;
        return sample;
      }
    }
    return null;
  }
  latest() {
    const v = this.view;
    const count = Math.min(v.getInt32(NUM_BUF, true), MAX_BUFS);
    let best = null;
    for (let i = 0; i < count; i++) {
      const slot = VAR_BUF + i * VAR_BUF_SIZE;
      const tick = v.getInt32(slot, true);
      if (!best || tick > best.tick) best = { slot, tick, offset: v.getInt32(slot + 4, true) };
    }
    return best;
  }
  readVarHeaders() {
    const v = this.view;
    const count = v.getInt32(NUM_VARS, true);
    const base = v.getInt32(VAR_HEADER_OFFSET, true);
    const wanted = new Set(WANTED);
    for (let i = 0; i < count; i++) {
      const at4 = base + i * VAR_HEADER_SIZE;
      const name = cstr(v, at4 + VAR_NAME, VAR_NAME_LENGTH, "latin1");
      if (!wanted.has(name)) continue;
      this.vars.set(name, {
        type: v.getInt32(at4 + VAR_TYPE, true),
        offset: v.getInt32(at4 + VAR_OFFSET, true)
      });
    }
  }
  value(row, name, fallback) {
    const found = this.vars.get(name);
    if (!found) return fallback;
    const at4 = row + found.offset;
    switch (found.type) {
      case TYPE_BOOL:
        return this.view.getUint8(at4);
      case TYPE_INT:
      case TYPE_BITFIELD:
        return this.view.getInt32(at4, true);
      case TYPE_FLOAT:
        return this.view.getFloat32(at4, true);
      case TYPE_DOUBLE:
        return this.view.getFloat64(at4, true);
      default:
        return fallback;
    }
  }
  read(row) {
    const lapDist = this.value(row, "LapDistPct", -1);
    const inWorld = this.value(row, "PlayerTrackSurface", 0) !== TRACK_SURFACE_NOT_IN_WORLD;
    const lastLapTime = this.value(row, "LapLastLapTime", -1);
    const bestLapTime = this.value(row, "LapBestLapTime", -1);
    this.incidentsRead = this.value(row, "PlayerCarMyIncidentCount", 0);
    return {
      sim: "iRacing",
      ...this.info,
      sessionTime: this.value(row, "SessionTime", 0),
      live: this.value(row, "IsOnTrack", 0) !== 0 && this.value(row, "IsReplayPlaying", 0) === 0 && inWorld && lapDist >= 0,
      inPit: this.value(row, "OnPitRoad", 0) !== 0,
      lapDist: Math.min(Math.max(lapDist, 0), 1),
      lapTime: this.value(row, "LapCurrentLapTime", -1),
      lastLapTime,
      speed: this.value(row, "Speed", 0),
      // the sim does not count a lap with an incident on it as a best lap
      lapValid: this.incidents === null || this.incidentsRead <= this.incidents,
      simDelta: this.vars.has("LapDeltaToSessionBestLap") ? {
        best: this.delta(row, "LapDeltaToBestLap", null),
        session: this.delta(row, "LapDeltaToSessionBestLap", bestLapTime > 0 ? bestLapTime : null),
        last: this.delta(row, "LapDeltaToSessionLastlLap", lastLapTime > 0 ? lastLapTime : null)
      } : void 0
    };
  }
  delta(row, name, refTime) {
    const ok = this.value(row, `${name}_OK`, 0) !== 0;
    return { delta: ok ? this.value(row, name, 0) : null, rate: this.value(row, `${name}_DD`, 0), refTime };
  }
};

// extension/sources/lmu.ts
var LMU_MAPPING = "LMU_Data";
var PLUGIN_PACK = 4;
var MAX_VEHICLES = 104;
var MAX_PATH = 260;
var EVENT_COUNT = 16;
var vec3 = struct([["_xyz", "f64", 3]], PLUGIN_PACK);
var wheel = struct(
  [
    ["_suspensionDeflection_to_pressure", "f64", 16],
    ["_temperature", "f64", 3],
    ["_wear", "f64"],
    ["_terrainName", "u8", 16],
    ["_surfaceType_to_staticUndeflectedRadius", "u8", 4],
    ["_verticalTireDeflection_to_tireCarcassTemperature", "f64", 4],
    ["_tireInnerLayerTemperature", "f64", 3],
    ["_optimalTemp", "f32"],
    ["_compoundIndex_compoundType", "u8", 2],
    ["_expansion", "u8", 18]
  ],
  PLUGIN_PACK
);
var telem = struct(
  [
    ["_id", "i32"],
    ["_deltaTime", "f64"],
    ["elapsedTime", "f64"],
    ["_lapNumber", "i32"],
    ["lapStartET", "f64"],
    ["vehicleName", "u8", 64],
    ["trackName", "u8", 64],
    ["_pos", vec3],
    ["localVel", vec3],
    ["_localAccel", vec3],
    ["_ori", vec3, 3],
    ["_localRot_localRotAccel", vec3, 2],
    ["_gear", "i32"],
    ["_engineRPM_to_engineMaxRPM", "f64", 23],
    ["_scheduledStops_to_headlights", "u8", 4],
    ["_dentSeverity", "u8", 8],
    ["_lastImpactET_lastImpactMagnitude", "f64", 2],
    ["_lastImpactPos", vec3],
    ["_engineTorque", "f64"],
    ["_currentSector", "i32"],
    ["_speedLimiter_to_rearTireCompoundIndex", "u8", 4],
    ["_fuelCapacity", "f64"],
    ["_frontFlapActivated_to_ignitionStarter", "u8", 4],
    ["_frontTireCompoundName", "u8", 18],
    ["_rearTireCompoundName", "u8", 18],
    ["_speedLimiterAvailable_antiStallActivated", "u8", 2],
    ["_unused", "u8", 2],
    ["_visualSteeringWheelRange", "f32"],
    ["_rearBrakeBias_turboBoostPressure", "f64", 2],
    ["_physicsToGraphicsOffset", "f32", 3],
    ["_physicalSteeringWheelRange", "f32"],
    ["_deltaBest_to_electricBoostWaterTemperature", "f64", 6],
    ["_electricBoostMotorState", "u8"],
    ["lapInvalidated", "bool"],
    ["_absActive_tcActive_speedLimiterActive", "bool", 3],
    ["_wiperState_to_trackLimitsSteps", "u8", 19],
    ["_regen_to_timeGapPlaceBehind", "f32", 7],
    ["vehicleModel", "u8", 30],
    ["_vehicleClass_vehicleChampionship", "u8", 2],
    ["_expansion", "u8", 20],
    ["_wheel", wheel, 4]
  ],
  PLUGIN_PACK
);
var vehicle = struct(
  [
    ["_id", "i32"],
    ["_driverName", "u8", 32],
    ["_vehicleName", "u8", 64],
    ["_totalLaps", "i16"],
    ["_sector_finishStatus", "i8", 2],
    ["lapDist", "f64"],
    ["_pathLateral_trackEdge", "f64", 2],
    ["_bestSector1_to_lastSector2", "f64", 5],
    ["lastLapTime", "f64"],
    ["_curSector1_curSector2", "f64", 2],
    ["_numPitstops_numPenalties", "i16", 2],
    ["isPlayer", "bool"],
    ["control", "i8"],
    ["inPits", "bool"],
    ["_place", "u8"],
    ["vehicleClass", "u8", 32],
    ["_timeBehindNext", "f64"],
    ["_lapsBehindNext", "i32"],
    ["_timeBehindLeader", "f64"],
    ["_lapsBehindLeader", "i32"],
    ["_lapStartET", "f64"],
    ["_pos_to_localAccel", vec3, 3],
    ["_ori", vec3, 3],
    ["_localRot_localRotAccel", vec3, 2],
    ["_headlights_to_individualPhase", "u8", 4],
    ["_qualification", "i32"],
    ["_timeIntoLap_estimatedLapTime", "f64", 2],
    ["_pitGroup", "u8", 24],
    ["_flag_underYellow", "u8", 2],
    ["countLapFlag", "u8"],
    ["_inGarageStall", "bool"],
    ["_upgradePack", "u8", 16],
    ["_pitLapDist_to_bestLapSector2", "f32", 3],
    ["_steamID", "u64"],
    ["_vehFilename", "u8", 32],
    ["_attackMode", "i16"],
    ["_fuelFraction_drsState", "u8", 2],
    ["_expansion", "u8", 4]
  ],
  PLUGIN_PACK
);
var scoringInfo = struct(
  [
    ["trackName", "u8", 64],
    ["_session", "i32"],
    ["currentET", "f64"],
    ["_endET", "f64"],
    ["_maxLaps", "i32"],
    ["lapDist", "f64"],
    ["_resultsStream", "ptr"],
    ["numVehicles", "i32"],
    ["_gamePhase_yellowFlagState", "u8", 2],
    ["_sectorFlag", "i8", 3],
    ["_startLight_numRedLights", "u8", 2],
    ["inRealtime", "bool"],
    ["_playerName", "u8", 32],
    ["_plrFileName", "u8", 64],
    ["_darkCloud_to_trackTemp", "f64", 4],
    ["_wind", vec3],
    ["_minPathWetness_maxPathWetness", "f64", 2],
    ["_gameMode_isPasswordProtected", "u8", 2],
    ["_serverPort", "u16"],
    ["_serverPublicIP", "u32"],
    ["_maxPlayers", "i32"],
    ["_serverName", "u8", 32],
    ["_startET", "f32"],
    ["_avgPathWetness", "f64"],
    ["_sessionTimeRemaining_timeOfDay", "f32", 2],
    ["_isFixedSetup_to_trackLimitsStepsPerPoint", "u8", 5],
    ["_expansion", "u8", 187],
    ["_vehicle", "ptr"]
  ],
  PLUGIN_PACK
);
var applicationState = struct(
  [
    ["_appWindow", "ptr"],
    ["_width_to_windowed", "u32", 4],
    ["_optionsLocation", "u8"],
    ["_optionsPage", "u8", 31],
    ["_expansion", "u8", 204]
  ],
  PLUGIN_PACK
);
var generic = struct([
  ["_events", "u32", EVENT_COUNT],
  ["_gameVersion", "i32"],
  ["_ffbTorque", "f32"],
  ["_appInfo", applicationState]
]);
var paths = struct([["_paths", "u8", MAX_PATH * 5]]);
var scoring = struct([
  ["info", scoringInfo],
  ["_scoringStreamSize", "u64"],
  ["vehicles", vehicle, MAX_VEHICLES],
  ["_scoringStream", "u8", 65536]
]);
var telemetry = struct([
  ["activeVehicles", "u8"],
  ["playerVehicleIdx", "u8"],
  ["playerHasVehicle", "bool"],
  ["telemInfo", telem, MAX_VEHICLES]
]);
var lmuLayout = struct([
  ["_generic", generic],
  ["_paths", paths],
  ["scoring", scoring],
  ["telemetry", telemetry]
]);
var SCORING_INFO = lmuLayout.at.scoring + scoring.at.info;
var VEHICLES = lmuLayout.at.scoring + scoring.at.vehicles;
var TELEMETRY = lmuLayout.at.telemetry;
var TELEM_INFO = TELEMETRY + telemetry.at.telemInfo;
var CONTROL_LOCAL_PLAYER = 0;
var COUNT_LAP_AND_TIME = 2;
var MAX_EXTRAPOLATION_SECONDS = 0.5;
var PAGE = 4096;
var LmuReader = class _LmuReader {
  constructor(view) {
    this.view = view;
  }
  view;
  playerSlot = -1;
  /** the block is a fixed struct, so its size says whether the game still matches these offsets */
  static create(view, log) {
    const slack = view.byteLength - lmuLayout.size;
    if (slack < 0 || slack >= PAGE) {
      log(`Le Mans Ultimate shared memory is ${view.byteLength} bytes, expected about ${lmuLayout.size}; skipping it`);
      return null;
    }
    return new _LmuReader(view);
  }
  pulse() {
    return this.view.getFloat64(TELEM_INFO + telem.at.elapsedTime, true);
  }
  poll() {
    const v = this.view;
    const count = v.getInt32(SCORING_INFO + scoringInfo.at.numVehicles, true);
    const trackLength = v.getFloat64(SCORING_INFO + scoringInfo.at.lapDist, true);
    if (count <= 0 || count > MAX_VEHICLES || !(trackLength > 0)) return null;
    if (v.getUint8(TELEMETRY + telemetry.at.playerHasVehicle) === 0) return null;
    const car = this.player(count);
    const index = v.getUint8(TELEMETRY + telemetry.at.playerVehicleIdx);
    if (car < 0 || index >= v.getUint8(TELEMETRY + telemetry.at.activeVehicles)) return null;
    const t = TELEM_INFO + index * telem.size;
    const elapsed = v.getFloat64(t + telem.at.elapsedTime, true);
    const vel = t + telem.at.localVel;
    const speed = Math.hypot(v.getFloat64(vel, true), v.getFloat64(vel + 8, true), v.getFloat64(vel + 16, true));
    if (!Number.isFinite(elapsed) || !Number.isFinite(speed)) return null;
    const since = elapsed - v.getFloat64(SCORING_INFO + scoringInfo.at.currentET, true);
    const ahead = speed * Math.min(Math.max(since, 0), MAX_EXTRAPOLATION_SECONDS);
    const metres = v.getFloat64(car + vehicle.at.lapDist, true) + ahead;
    const lapDist = (metres % trackLength + trackLength) % trackLength / trackLength;
    const model = cstr(v, t + telem.at.vehicleModel, 30) || cstr(v, car + vehicle.at.vehicleClass, 32);
    const track = cstr(v, SCORING_INFO + scoringInfo.at.trackName, 64);
    return {
      sim: "Le Mans Ultimate",
      track,
      trackId: track,
      car: model || cstr(v, t + telem.at.vehicleName, 64),
      carId: model || cstr(v, t + telem.at.vehicleName, 64),
      trackLength,
      sessionTime: elapsed,
      live: v.getUint8(SCORING_INFO + scoringInfo.at.inRealtime) !== 0 && v.getInt8(car + vehicle.at.control) === CONTROL_LOCAL_PLAYER,
      inPit: v.getUint8(car + vehicle.at.inPits) !== 0,
      lapDist,
      lapTime: elapsed - v.getFloat64(t + telem.at.lapStartET, true),
      lastLapTime: v.getFloat64(car + vehicle.at.lastLapTime, true),
      speed,
      lapValid: v.getUint8(t + telem.at.lapInvalidated) === 0 && v.getUint8(car + vehicle.at.countLapFlag) === COUNT_LAP_AND_TIME
    };
  }
  /** offset of the player's scoring entry, which keeps its slot for as long as the session lasts */
  player(count) {
    const v = this.view;
    const cached = VEHICLES + this.playerSlot * vehicle.size;
    if (this.playerSlot >= 0 && this.playerSlot < count && v.getUint8(cached + vehicle.at.isPlayer) !== 0)
      return cached;
    for (let i = 0; i < count; i++) {
      const at4 = VEHICLES + i * vehicle.size;
      if (v.getUint8(at4 + vehicle.at.isPlayer) !== 0) {
        this.playerSlot = i;
        return at4;
      }
    }
    this.playerSlot = -1;
    return -1;
  }
};

// extension/sources/r3e.ts
var R3E_MAPPING = "$R3E";
var PACK = 1;
var TIRES = 4;
var playerData = struct(
  [
    ["_userId", "i32"],
    ["simulationTicks", "i32"],
    ["simulationTime", "f64"],
    ["_position_to_localGForce", "f64", 33],
    ["_steeringForce_to_torqueMguK", "f64", 9],
    ["_suspensionDeflection_to_rideHeight", "f64", 4 * TIRES],
    ["_frontWingHeight_to_thirdSpringSuspensionVelocityRear", "f64", 7],
    ["_unused", "f64", 3]
  ],
  PACK
);
var flags = struct([["_yellow_to_blackAndWhite", "i32", 14]], PACK);
var cutTrackPenalties = struct([["_driveThrough_to_slowDown", "f32", 5]], PACK);
var driverInfo = struct(
  [
    ["_name", "u8", 64],
    ["_carNumber_classId", "i32", 2],
    ["modelId", "i32"],
    ["_teamId_to_engineType", "i32", 7],
    ["_carWidth_to_unused2", "f32", 6]
  ],
  PACK
);
var driverData = struct(
  [
    ["_driverInfo", driverInfo],
    ["_finishStatus_place_placeClass", "i32", 3],
    ["_lapDistance_lapDistanceFraction", "f32", 2],
    ["_position", "f32", 3],
    ["_trackSector_completedLaps_currentLapValid", "i32", 3],
    ["_lapTimeCurrentSelf", "f32"],
    ["_sectorTimes", "f32", 9],
    ["_timeDeltaFront_timeDeltaBehind", "f32", 2],
    ["_pitstopStatus_inPitlane_numPitstops", "i32", 3],
    ["_penalties", cutTrackPenalties],
    ["_carSpeed", "f32"],
    ["_tireTypeFront_to_tireSubtypeRear", "i32", 4],
    ["_basePenaltyWeight_aidPenaltyWeight", "f32", 2],
    ["_drsState_ptpState", "i32", 2],
    ["_virtualEnergy", "f32"],
    ["_penaltyType_penaltyReason_engineState", "i32", 3],
    ["_orientation", "f32", 3],
    ["_unused", "f32", 3]
  ],
  PACK
);
var r3eLayout = struct(
  [
    ["versionMajor", "i32"],
    ["_versionMinor", "i32"],
    ["allDriversOffset", "i32"],
    ["driverDataSize", "i32"],
    ["_gameMode", "i32"],
    ["gamePaused", "i32"],
    ["gameInMenus", "i32"],
    ["gameInReplay", "i32"],
    ["_gameUsingVr_gamePlayerInGarage", "i32", 2],
    ["player", playerData],
    ["trackName", "u8", 64],
    ["layoutName", "u8", 64],
    ["_trackId", "i32"],
    ["layoutId", "i32"],
    ["layoutLength", "f32"],
    ["_sectorStartFactors", "f32", 3],
    ["_raceSessionLaps_raceSessionMinutes", "i32", 6],
    ["_eventIndex_to_sessionLengthFormat", "i32", 4],
    ["_sessionPitSpeedLimit", "f32"],
    ["_sessionPhase_to_numberOfLaps", "i32", 5],
    ["_sessionTimeDuration_sessionTimeRemaining", "f32", 2],
    ["_maxIncidentPoints", "i32"],
    ["_eventUnused", "f32", 2],
    ["_pitWindowStatus_to_pitWindowEnd", "i32", 3],
    ["inPitlane", "i32"],
    ["_pitMenuSelection", "i32"],
    ["_pitMenuState", "i32", 12],
    ["_pitState", "i32"],
    ["_pitTotalDuration_pitElapsedTime", "f32", 2],
    ["_pitAction_numPitstops", "i32", 2],
    ["_pitMinDurationTotal_pitMinDurationLeft", "f32", 2],
    ["_flags", flags],
    ["_position_to_cutTrackWarnings", "i32", 4],
    ["_penalties", cutTrackPenalties],
    ["_numPenalties_completedLaps", "i32", 2],
    ["currentLapValid", "i32"],
    ["_trackSector", "i32"],
    ["_lapDistance", "f32"],
    ["lapDistanceFraction", "f32"],
    ["_lapTimeBestLeader_to_sectorTimeBestSelf", "f32", 9],
    ["lapTimePreviousSelf", "f32"],
    ["_sectorTimePreviousSelf", "f32", 3],
    ["lapTimeCurrentSelf", "f32"],
    ["_sectorTimeCurrentSelf", "f32", 3],
    ["_lapTimeDeltaLeader_to_timeDeltaBestSelf", "f32", 5],
    ["_bestIndividualSectorTimes", "f32", 9],
    ["_incidentPoints_lapValidState_prevLapValid", "i32", 3],
    ["_dischargeRate_brakeRegen_unused1", "f32", 3],
    ["vehicleInfo", driverInfo],
    ["_playerName", "u8", 64],
    ["controlType", "i32"],
    ["carSpeed", "f32"],
    ["_engineRps_maxEngineRps_upshiftRps", "f32", 3],
    ["_gear_numGears", "i32", 2],
    ["_carCgLocation_carOrientation_localAcceleration", "f32", 9],
    ["_totalMass_to_steerInputRaw", "f32", 19],
    ["_steerLockDegrees_steerWheelRangeDegrees", "i32", 2],
    ["_aidSettings", "i32", 5],
    ["_drs", "i32", 4],
    ["_pitLimiter", "i32"],
    ["_pushToPass", "i32", 5],
    ["_brakeBias", "f32"],
    ["_drsNumActivationsTotal_ptpNumActivationsTotal", "i32", 2],
    ["_batterySoc_waterLeft", "f32", 2],
    ["_absSetting_to_tireType", "i32", 4],
    ["_tireRps_to_tireDirt", "f32", 7 * TIRES],
    ["_tireTemp", "f32", 6 * TIRES],
    ["_tireTypeFront_to_tireSubtypeRear", "i32", 4],
    ["_brakeTemp", "f32", 4 * TIRES],
    ["_brakePressure", "f32", TIRES],
    ["_tractionControlSetting_to_engineBrakeSetting", "i32", 3],
    ["_tractionControlPercent", "f32"],
    ["_tireOnMtrl", "i32", TIRES],
    ["_tireLoad", "f32", TIRES],
    ["_carDamage", "f32", 6],
    ["_numCars", "i32"],
    ["allDrivers", "u8", 0]
  ],
  PACK
);
var at3 = r3eLayout.at;
var VERSION_MAJOR = 3;
var CONTROL_PLAYER = 0;
var R3eReader = class _R3eReader {
  constructor(view) {
    this.view = view;
  }
  view;
  /** the game says where its driver array starts and how big each entry is, which checks every offset before it */
  static create(view, log) {
    if (view.byteLength < r3eLayout.size) return null;
    const major = view.getInt32(at3.versionMajor, true);
    if (major === 0) return null;
    const offset = view.getInt32(at3.allDriversOffset, true);
    const size = view.getInt32(at3.driverDataSize, true);
    if (major !== VERSION_MAJOR || offset !== at3.allDrivers || size !== driverData.size) {
      log(
        `RaceRoom shared memory is version ${major} with drivers at ${offset} (${size} bytes each), expected version ${VERSION_MAJOR} with drivers at ${at3.allDrivers} (${driverData.size} bytes each); skipping it`
      );
      return null;
    }
    return new _R3eReader(view);
  }
  pulse() {
    return this.view.getInt32(at3.player + playerData.at.simulationTicks, true);
  }
  poll() {
    const v = this.view;
    const trackLength = v.getFloat32(at3.layoutLength, true);
    const lapDist = v.getFloat32(at3.lapDistanceFraction, true);
    if (!(trackLength > 0)) return null;
    const track = cstr(v, at3.trackName, 64);
    const layout = cstr(v, at3.layoutName, 64);
    const model = v.getInt32(at3.vehicleInfo + driverInfo.at.modelId, true);
    return {
      sim: "RaceRoom",
      track: layout ? `${track} ${layout}` : track,
      trackId: String(v.getInt32(at3.layoutId, true)),
      car: `Car ${model}`,
      carId: String(model),
      trackLength,
      sessionTime: v.getFloat64(at3.player + playerData.at.simulationTime, true),
      live: v.getInt32(at3.gamePaused, true) === 0 && v.getInt32(at3.gameInMenus, true) === 0 && v.getInt32(at3.gameInReplay, true) === 0 && v.getInt32(at3.controlType, true) === CONTROL_PLAYER && lapDist >= 0,
      inPit: v.getInt32(at3.inPitlane, true) === 1,
      lapDist: Math.min(Math.max(lapDist, 0), 1),
      lapTime: v.getFloat32(at3.lapTimeCurrentSelf, true),
      lastLapTime: v.getFloat32(at3.lapTimePreviousSelf, true),
      speed: v.getFloat32(at3.carSpeed, true),
      lapValid: v.getInt32(at3.currentLapValid, true) !== 0
    };
  }
};

// extension/sources/index.ts
function mapped(name, mapping, make) {
  return {
    name,
    open(log) {
      const memory = openMapping(mapping);
      if (!memory) return null;
      const reader = make(memory.view, log);
      if (!reader) {
        memory.close();
        return null;
      }
      return { poll: () => reader.poll(), pulse: () => reader.pulse(), close: () => memory.close() };
    }
  };
}
var SOURCES = [
  mapped("iRacing", IRACING_MAPPING, (view) => new IRacingReader(view)),
  mapped("Le Mans Ultimate", LMU_MAPPING, LmuReader.create),
  mapped("Automobilista 2", AMS2_MAPPING, Ams2Reader.create),
  mapped("RaceRoom", R3E_MAPPING, R3eReader.create)
];
var SCAN_INTERVAL_MS = 1e3;
var QUIET_LIMIT_MS = 3e3;
var STALE_LIMIT_MS = 5e3;
var SourceManager = class {
  constructor(factories, log) {
    this.factories = factories;
    this.log = log;
  }
  factories;
  log;
  active = null;
  lastScanAt = -Infinity;
  lastSampleAt = 0;
  lastPulse = NaN;
  lastPulseAt = 0;
  warned = /* @__PURE__ */ new Set();
  get activeName() {
    return this.active?.factory.name ?? null;
  }
  poll(now) {
    if (!this.active) {
      if (now - this.lastScanAt < SCAN_INTERVAL_MS) return null;
      this.lastScanAt = now;
      return this.scan(now);
    }
    const { source } = this.active;
    let sample;
    let pulse;
    try {
      sample = source.poll();
      pulse = source.pulse();
    } catch (error) {
      this.log(`${this.active.factory.name} reader failed: ${error}`);
      this.drop();
      return null;
    }
    if (pulse !== this.lastPulse) {
      this.lastPulse = pulse;
      this.lastPulseAt = now;
    } else if (now - this.lastPulseAt > STALE_LIMIT_MS) {
      this.lastPulseAt = now;
      if (!this.reopen()) return null;
    }
    if (sample) this.lastSampleAt = now;
    else if (now - this.lastSampleAt > QUIET_LIMIT_MS) this.drop();
    return sample;
  }
  close() {
    this.drop();
  }
  scan(now) {
    for (const factory of this.factories) {
      let source = null;
      try {
        source = factory.open((message) => this.warnOnce(message));
        const sample = source?.poll() ?? null;
        if (source && sample) {
          this.active = { factory, source };
          this.lastSampleAt = now;
          this.lastPulse = source.pulse();
          this.lastPulseAt = now;
          this.log(`reading ${factory.name}`);
          return sample;
        }
      } catch (error) {
        this.warnOnce(`${factory.name} reader failed: ${error}`);
      }
      source?.close();
    }
    return null;
  }
  reopen() {
    const { factory, source } = this.active;
    source.close();
    let fresh = null;
    try {
      fresh = factory.open((message) => this.warnOnce(message));
    } catch (error) {
      this.warnOnce(`${factory.name} reader failed: ${error}`);
    }
    if (fresh) {
      this.active = { factory, source: fresh };
      return true;
    }
    this.active = null;
    this.log(`lost ${factory.name}`);
    return false;
  }
  drop() {
    if (!this.active) return;
    this.log(`lost ${this.active.factory.name}`);
    this.active.source.close();
    this.active = null;
  }
  warnOnce(message) {
    if (this.warned.has(message)) return;
    this.warned.add(message);
    this.log(message);
  }
};

// extension/core.ts
var POLL_MS = 16;
var LIVE_FRAME_MS = 33;
var IDLE_FRAME_MS = 1e3;
var GONE_AFTER_MS = 3e3;
var Runtime = class {
  constructor(host, factories, refMode = "best") {
    this.host = host;
    this.engine = new LapEngine({
      loadBest: (key) => host.loadBest(key),
      saveBest: (key, best) => host.saveBest(key, best),
      changed: () => {
        this.sessionDirty = true;
      }
    });
    this.engine.refMode = refMode;
    this.sources = new SourceManager(factories, host.log);
  }
  host;
  engine;
  sources;
  timer;
  lastSampleAt = -Infinity;
  lastFrameAt = -Infinity;
  sessionDirty = false;
  start() {
    this.timer ??= setInterval(() => this.tick(performance.now()), POLL_MS);
  }
  stop() {
    clearInterval(this.timer);
    this.timer = void 0;
    this.sources.close();
  }
  /** `reply` reaches only the screen that asked */
  command(command, reply) {
    switch (command.t) {
      case "hello":
        reply(this.engine.session());
        reply(this.engine.frame());
        return;
      case "ref":
        this.engine.setRefMode(command.mode);
        this.host.saveRefMode(command.mode);
        return;
      case "clearBest":
        this.engine.clearBest();
        return;
      case "resetSession":
        this.engine.resetSession();
        return;
    }
  }
  tick(now) {
    const sample = this.sources.poll(now);
    if (sample) {
      this.lastSampleAt = now;
      this.engine.update(sample);
    } else if (now - this.lastSampleAt > GONE_AFTER_MS) {
      this.engine.idle();
    }
    if (!this.host.watched()) return;
    if (this.sessionDirty) {
      this.sessionDirty = false;
      this.host.emit(this.engine.session());
    }
    const frame = this.engine.frame();
    if (now - this.lastFrameAt >= (frame.live ? LIVE_FRAME_MS : IDLE_FRAME_MS)) {
      this.lastFrameAt = now;
      this.host.emit(frame);
    }
  }
};

// extension/main.ts
var BEST_PREFIX = "best:";
var REF_MODE_KEY = "refMode";
var runtime;
var consoleReleased = false;
try {
  consoleReleased = releaseOwnConsole();
} catch {
}
defineExtension({
  async start(ctx) {
    const bests = /* @__PURE__ */ new Map();
    let ready;
    ctx.on("device", (event) => {
      if (event.type === "disconnected" || !event.device.active) return;
      ready?.command({ t: "hello" }, (message) => event.device.send(json(message)));
    });
    ctx.on("message", (device, message) => {
      const command = asJson(message);
      if (isCommand(command)) ready?.command(command, (reply) => device.send(json(reply)));
    });
    for (const key of await ctx.kv.list()) {
      if (!key.startsWith(BEST_PREFIX)) continue;
      const best = decodeReference(await ctx.kv.get(key));
      if (best) bests.set(key.slice(BEST_PREFIX.length), best);
    }
    const stored = await ctx.kv.get(REF_MODE_KEY);
    const failed = (what) => (error) => ctx.log.warn(`could not ${what}: ${error}`);
    ready = runtime = new Runtime(
      {
        log: (message) => ctx.log.info(message),
        emit: (message) => ctx.broadcast(json(message)),
        watched: () => ctx.devices.some((device) => device.active),
        loadBest: (key) => bests.get(key) ?? null,
        saveBest(key, best) {
          if (best) {
            bests.set(key, best);
            ctx.kv.set(BEST_PREFIX + key, encodeReference(best)).catch(failed("save the best lap"));
          } else {
            bests.delete(key);
            ctx.kv.delete(BEST_PREFIX + key).catch(failed("clear the best lap"));
          }
        },
        saveRefMode: (mode) => void ctx.kv.set(REF_MODE_KEY, mode).catch(failed("save the reference mode"))
      },
      SOURCES,
      stored && REF_MODES.includes(stored) ? stored : "best"
    );
    runtime.start();
    ctx.log.info(`lap timer up with ${bests.size} stored best laps${consoleReleased ? ", console window closed" : ""}`);
  },
  stop() {
    runtime?.stop();
  }
});
